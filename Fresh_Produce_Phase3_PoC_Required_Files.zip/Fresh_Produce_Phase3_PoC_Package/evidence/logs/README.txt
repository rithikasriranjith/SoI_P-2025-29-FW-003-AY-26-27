Save actual execution logs, calculations, failures, and retest records here. Do not replace an original failure with a later successful retest.
