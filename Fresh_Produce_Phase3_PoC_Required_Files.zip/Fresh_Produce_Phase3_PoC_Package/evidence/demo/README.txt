Record and place the actual demonstration video (maximum 2 minutes) in this folder. The video is not pre-created; do not claim it exists until recorded.
